Dependencies
============

[backbone-pageable](http://github.com/wyuenho/backbone-pageable/)

Usage
====

See the [Paginator](http://wyuenho.github.com/backgrid/#api-paginator) section
in the documentation.
